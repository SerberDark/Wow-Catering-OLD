;(function ($) {
  //init formstayler
  $('select').styler();
})(jQuery);